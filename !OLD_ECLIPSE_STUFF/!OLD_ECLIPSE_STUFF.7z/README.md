﻿GPS2SMS
==============

Do you want to convert your GPS location to SMS? 
App allows you to share your location via SMS or any other app (like e-mail, messengers, etc.). You GPS receiver should operate.
GPS share now possible with using of clipboard.

This in an Android application.