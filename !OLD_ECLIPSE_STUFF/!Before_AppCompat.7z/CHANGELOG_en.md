# Changelog

## v3.3.4 / 11.01.2015
- Swedish and Slovak translations added
- Separate button with icon of the favourite app for faster sharing ("send via Gmail app" for example)
- Option in Settings for manual language selecting
- Option in Settings which allows user to choose what exactly to send via SMS
- Option "Send in Navitel format" moved to "SMS Text" and "Clipboard content" options
- Long tap on "Fav button" to choose favourite app
- New icon for "Add point" button
- Tiny fixes and optimizations.

## v3.3.3 / 08.01.2015
- Ukrainian and Portuguese translations added
- Tiny fixes and optimizations.
